document.getElementById('ageForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const day = parseInt(document.getElementById('day').value);
  const month = parseInt(document.getElementById('month').value) - 1; // JS months are 0-based
  const year = parseInt(document.getElementById('year').value);
  const errorMsg = document.getElementById('errorMsg');
  const result = document.getElementById('result');

  errorMsg.textContent = '';
  result.textContent = '';

  const dob = new Date(year, month, day);
  const today = new Date();

  if (dob > today || isNaN(dob.getTime())) {
    errorMsg.textContent = "Please enter a valid date of birth.";
    return;
  }

  let ageYears = today.getFullYear() - dob.getFullYear();
  let ageMonths = today.getMonth() - dob.getMonth();
  let ageDays = today.getDate() - dob.getDate();

  if (ageDays < 0) {
    ageMonths--;
    const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    ageDays += lastMonth.getDate();
  }

  if (ageMonths < 0) {
    ageYears--;
    ageMonths += 12;
  }

  result.innerHTML = `You are <strong>${ageYears}</strong> years, <strong>${ageMonths}</strong> months, and <strong>${ageDays}</strong> days old.`;
});
